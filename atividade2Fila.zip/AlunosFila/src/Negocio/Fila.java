package Negocio;


																						// import's


import javax.swing.JOptionPane;                       								
import Modelagem.Estudantes;




																						// classe Fila
public class Fila {                                        
	
																				// atributos e variaveis de fila 
	
    private Estudantes F[];  
    private int inicio;
    private int fim;
    private int tamanho;
    private int quantidadePessoas;

    
    
    
    			// metodo que inicia as variaveis existentes da fila 
    
    public Fila(int tamanho) {  																													 
        this.tamanho = tamanho;                 																 	 // inicia o valor de tamanho como 0 
        F = new Estudantes[tamanho];           
        inicio = fim = -1;                    																		 // inicio e fim iniciam com -1
        quantidadePessoas = 0;             																			// quantidade de pessoas inicia igual a 0
    }

    
    
    
    				// metodo para verificaçao se a lista esta vazia 
    
    public boolean estaVazia() {
        return quantidadePessoas == 0; 
    }

    
    				// metodo para verificacao se a lista esta cheia 
    
    public boolean estaCheio() { 																															
        return quantidadePessoas == tamanho;
    }

    
    				// metodo para incluir estudante na fila 
    
    public void incluirFila(Estudantes estudante) {   																										
        if (!estaCheio()) {
            if (inicio == -1) {
                inicio = 0;           
            }
            fim++;
            F[fim] = estudante;
            quantidadePessoas++;
        } else {
            JOptionPane.showMessageDialog(null, "A fila está cheia. Não é possível adicionar mais estudantes.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    			// metodo para mostrar fila de estudantes //
    
    public void mostrarFila() {                                     																						 
        if (estaVazia()) {
            JOptionPane.showMessageDialog(null, "A fila está vazia.", "Fila Vazia", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String detalhesFila = "Fila de Estudantes:\n";
        for (int i = inicio; i <= fim; i++) {
            Estudantes estudante = F[i];
            detalhesFila += "Nome: " + estudante.getNome() + ", Curso: " + estudante.getCurso() + ", Matrícula: " + estudante.getMatricula() + "\n";
        }

        JOptionPane.showMessageDialog(null, detalhesFila, "Mostrar Fila", JOptionPane.INFORMATION_MESSAGE);
    }

    
    		// metodo pra tirar o ultimo estudante da fila //
    
    public void retirarDaFila() {          																											  			
        if (!estaVazia()) {
            inicio++;
            quantidadePessoas--;
        } else {
            JOptionPane.showMessageDialog(null, "A fila está vazia. Não é possível remover estudantes.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}