package Visao;

import javax.swing.JOptionPane;                             									  // import's 
import Modelagem.Estudantes;
import Negocio.Fila;

public class Main {    																																												 // classe main 

    public static void main(String[] args) {     																																					 // metodo main 
    	
    	
    	
        Fila fila = new Fila(10);      // inicia a fila com 10 posiçoes
        
        
        
        
        																			// interface JOptionpane com suas opçoes //

        
        
        while (true) {
            String opcao = JOptionPane.showInputDialog(null, "Selecione uma opção:\n1. Adicionar estudante à fila\n2. Mostrar fila\n3. Retirar o ultimo estudante da fila\n4. Sair", "Menu", JOptionPane.QUESTION_MESSAGE);

            if (opcao == null || opcao.equals("")) {
                JOptionPane.showMessageDialog(null, "Opção inválida. Por favor, escolha uma opção válida.", "Erro", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            																																									//escolhas 
            switch (opcao) {
                case "1":
                    adicionarEstudante(fila);            																														 // adicionar estudante
                    break;
                case "2":
                    mostrarFila(fila);                                                          																				// mostrar fila
                    break;
                case "3":
                    retirarEstudante(fila);                                                                                                                                   	//retirar o ultimo estudante
                    break;
                case "4":                                                                                    																	// opçao 4 sair , fecha o aplicativo e exibe mensagem
                    JOptionPane.showMessageDialog(null, "fechando o aplicativo... obrigado por usar! ", "Sair", JOptionPane.INFORMATION_MESSAGE);
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida. Por favor, escolha uma opção válida.", "Erro", JOptionPane.ERROR_MESSAGE);                				// caso escolha uma opçao invalida
            }
        }
    }
    
    
    															// chamada no metodo adicionar com espeficiações :  nome , curso e matricula //
    

    private static void adicionarEstudante(Fila fila) {
        String nome = JOptionPane.showInputDialog(null, "Digite o nome completo do estudante:", "Adicionar Estudante", JOptionPane.QUESTION_MESSAGE);
        if (nome == null || nome.equals("")) {
            return; 																																			// O usuário cancelou ou deixou o campo em branco, então saímos do método
        }
        
        String curso = JOptionPane.showInputDialog(null, "Digite o curso do estudante:", "Adicionar Estudante", JOptionPane.QUESTION_MESSAGE);
        if (curso == null || curso.equals("")) {
            return; 																																			// O usuário cancelou ou deixou o campo em branco, então saímos do método
        }

        String matriculaStr = JOptionPane.showInputDialog(null, "Digite a matrícula do estudante:", "Adicionar Estudante", JOptionPane.QUESTION_MESSAGE);
        if (matriculaStr == null || matriculaStr.equals("")) {
            return; 																																			// O usuário cancelou ou deixou o campo em branco, então saímos do método
        }

        int matricula;
        try {
            matricula = Integer.parseInt(matriculaStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Matrícula inválida. Por favor, insira um número inteiro valido .", "Erro", JOptionPane.ERROR_MESSAGE);
            return; 																																				// Saímos do método se a matrícula não pôde ser convertida para um número
        }

        Estudantes estudante = new Estudantes(nome, curso, matricula); 																											
        fila.incluirFila(estudante);																																				// inclui o estudante na fila 
    }

    private static void mostrarFila(Fila fila) {                                          																					// exibe a fila 
        fila.mostrarFila();
    }

    private static void retirarEstudante(Fila fila) {																													// retira o ultimo estudante da fila
        fila.retirarDaFila();
    }
}